
package com.mydomain.takehomeapp.services.apihelper;

/*
 * @author jmonani
 *
 * base class for api response
 */
public class BaseApiResponse {
	// api response error
	public String error;
}
